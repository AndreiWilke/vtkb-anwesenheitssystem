# Handoff: VTKB Anwesenheit — Redesign „Ruhig & hochwertig"

## Overview
Visuelles Redesign der mobilen PWA **VTKB Anwesenheit** (`apps/web`). Ziel: das vom
Verein als „unübersichtlich" empfundene aktuelle UI in eine ruhige, hochwertige
**Dojo-Ästhetik** überführen — viel Weißraum, klare Hierarchie, zurückhaltende
Farbe. Funktion, Flow, Routing, Datenmodell und Komponenten-Struktur bleiben
**unverändert**. Es ist ein reiner Look-&-Feel-Layer.

## About the Design Files
Die Datei `VTKB Redesign.dc.html` in diesem Bundle ist eine **Design-Referenz in
HTML** — ein Prototyp, der Aussehen und Aufbau zeigt, **kein** produktiver Code zum
1:1-Kopieren. Aufgabe ist, diesen Look im **bestehenden** `apps/web` (React +
TypeScript + Vite, klassenbasiertes CSS in `src/styles.css`, Icons via
`lucide-react`) umzusetzen — über die vorhandenen Komponenten und Klassennamen.

Der Prototyp zeigt die vier Hauptscreens als Telefon-Frames nebeneinander; die
Geräterahmen und die nebeneinander gestellten Frames sind nur Präsentation und
gehören **nicht** in die App.

## Fidelity
**High-fidelity.** Finale Farben (Hex), Schriften, Größen und Spacing sind
verbindlich. Das Redesign ist bewusst als **CSS-/Token-Austausch** auf der
bestehenden Markup-Struktur angelegt — der schnellste Weg ist `styles.redesign.css`
(liegt bei) in `src/styles.css` einzuarbeiten, plus zwei kleine Markup-Änderungen
(Logo-Swap, Schrift-Links). Siehe „Implementation Plan".

---

## Design Tokens

| Token | Wert | Verwendung | Vorher |
|---|---|---|---|
| `--paper` | `#f4f1ea` | App-Hintergrund | `#eef1f5` |
| Canvas (außerhalb Shell) | `#e6e1d6` | `html`/`:root` background | — |
| `--surface` | `#fffdf9` | Karten, Header, Nav (warmes Weiß) | `#ffffff` |
| `--surface-soft` | `#faf7f0` | weiche Flächen | `#f6f7f9` |
| `--ink` | `#221d18` | Text | `#172033` |
| `--muted` | `#6f655b` | Sekundärtext | `#5d687a` |
| `--faint` | `#a79c8f` | Mono-Labels, Hilfstext (NEU) | — |
| `--line` | `#e7e0d3` | Haarlinie | `#d5dae2` |
| `--line-soft` | `#efe9de` | feine Trenner in Karten (NEU) | — |
| `--red` | `#9d1f17` | **nur** Primäraktion + Kernzahlen | `#b42318` |
| `--red-strong` | `#7d1610` | Hover | `#961b13` |
| `--red-tint` | `#faf2f0` | „anwesend"-Zeile Hintergrund (NEU) | — |
| `--accent` | `#2c4257` | Indigo: Sekundärinfo, Tags, Links (NEU) | — |
| `--green` | `#2f8a4e` | Status / Gürtel grün | `#087a47` |
| `--shadow` | `0 12px 30px -14px rgb(34 29 24 / 16%)` | Karten/Shell | — |
| `--radius` | `16px` | Karten | `14px` |

**Akzent-Logik:** Rot trägt ausschließlich die jeweils **wichtigste Aktion** und
die **Kernzahlen** (z. B. „anwesend"-Zähler, Gesamtanzahl). Alles früher rote
Sekundäre (Tags, Links, Chevrons) wird **Indigo** oder neutral. Das nimmt der
Oberfläche die Unruhe.

### Typografie
Drei Schriften (Google Fonts):
- **Spectral** (Serif, `600`) — Überschriften `h1/h2`, große Zahlen/Stats.
- **IBM Plex Sans** (`400/500/600`) — gesamte UI, Body, Buttons.
- **IBM Plex Mono** (`500`) — Mikro-Labels: Kicker, Abschnittslabels, Stat-Labels,
  Detail-Zeilen-Bezeichner; immer `UPPERCASE`, `letter-spacing ~0.1em`,
  `font-size 9–11px`, Farbe `--faint`.

Einbinden in `apps/web/index.html` `<head>`:
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Spectral:wght@400;500;600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@500&display=swap" rel="stylesheet">
```

Typo-Skala (mobil):
- `h1`: 25px / Spectral 600 / line-height 1.1 / tracking -0.01em
- `h2` (Kartentitel): 23px / Spectral 600
- Body: 13–14px / Plex Sans 400–500
- Mono-Label: 9–11px / Plex Mono 500 / uppercase / tracking 0.1–0.14em
- Kernzahl (Zähler/Stat): 28–36px / Spectral 600

### Spacing & Form
- App-Padding (`.app-main`): großzügig, ~18–22px horizontal.
- Karten-Radius 16px, Buttons 12–13px, Tags `pill` (999px).
- **Weniger Rahmen:** Abschnitte durch Weißraum + Haarlinien trennen, nicht durch
  geschachtelte Kästen. Detail-/Listzeilen mit `--line-soft` als Unterlinie.
- Schatten weich und tief-versetzt (`--shadow-card`), nie hart.

---

## Screens / Views
Markup-Struktur bleibt; nur Stil ändert sich. Klassennamen unten = bestehende
Klassen aus `src/styles.css` / `src/components.tsx`.

### 1. Start (`START`)
- **Zweck:** Empfohlene Trainingseinheit bestätigen und starten.
- **Layout:** Mono-Kicker (Datum) → Mono-Label „Heute empfohlen" → **Hero-Karte**
  `.session-focus` → „Direkt anschließend"-Zeile → „Zuletzt abgeschlossen"-Liste.
- **Hero-Karte:** `--surface`, Radius 16, **3px roter Balken links**, weicher
  Schatten. Titel `h2` in Spectral. Tag „Vorgeschlagen" rechts oben =
  `.status-tag.good` in **Indigo** (`--accent-tint` Hintergrund). Darunter
  `.detail-list` als drei Zeilen *Zeit / Dojo / Verantwortlich*: Mono-Label links,
  Wert rechtsbündig, dünne `--line-soft`-Trenner. Primärbutton „Training starten →"
  (`--red`, Radius 13, weicher roter Schatten), darunter zentrierter Textlink
  „Andere Einheit auswählen" in Rot.
- **Folge-Listen:** Mono-Label-Header, rechtsbündig Indigo-Link „Auswertung".
  Zeilen: Titel links, rechts Anzahl mit Serif-Zahl + „anwesend".

### 2. Manuelle Erfassung (`MANUAL`)
- **Zweck:** Anwesenheit setzen (default abwesend, Tap = anwesend).
- **Layout:** `‹ Zurück` Textlink → `h2` „Erfassung" (Spectral) → Hilfstext →
  Suchfeld → zwei Filter-Pills (Altersgruppe / Gürtel) → **Zähler** → Mitgliedsliste.
- **Zähler:** kräftige `--ink`-Unterlinie; links Serif-Zahl in **Rot** (`2`) +
  „anwesend", rechts Mono „40 sichtbar".
- **Mitgliedszeile** (`.member-row` / `.member-main`): Avatar 40px (Tinte `#2b2620`),
  Name (Plex 600), Meta-Zeile = Alterklasse · Gürtelbalken · „Weiß · 10. Kyu"
  (Mono/klein). Rechts Toggle: abwesend = Outline „Abwesend"; anwesend = rot gefüllt
  „✓ Anwesend". **Anwesende Zeile:** `--red-tint` Hintergrund + `inset 2px` roter
  Balken links + roter Avatar.

### 3. Gesamtliste prüfen (`SUMMARY`)
- **Zweck:** Trainerprüfung der Gesamtliste vor Abschluss.
- **Layout:** `h2` „Gesamtliste prüfen" → Mono-Metazeile (Einheit · Zeit · Dojo) →
  **Hero-Stat** „Gesamt anwesend / 3" (Karte, leichter `--red`-Tint, Serif-Zahl 36px
  rot) → vier Abschnitte → Primärbutton „Einheit abschließen" (unten).
- **Abschnitte** (Verantwortlicher Trainer / Assistenztrainer / Teilnehmer / Gäste):
  Header = Mono-Label links + Serif-Anzahl rechts, getrennt durch kräftige
  `--ink`-Unterlinie. Darunter Personenzeilen (Avatar 36 + Name + Gürtel). Leere
  Abschnitte: „Keine Personen" in `--faint`. Gäste-Anzahl in **Indigo**.

### 4. Auswertung (`STATS`)
- **Zweck:** Demo-Auswertung / Ranking der Teilnahmen.
- **Layout:** `h2` „Auswertung" → Mono-Untertitel → **Stat-Streifen** (3 Werte) →
  Mono-Label „Besuchte Einheiten" → Ranking-Liste.
- **Stat-Streifen:** drei Zellen nebeneinander, getrennt durch **vertikale
  Haarlinien** (kein Kasten). Je Zelle Serif-Zahl 28px + Mono-Label darunter
  (40 aktive Mitglieder / 114 Teilnahmen / 18 Trainereinsätze).
- **Ranking-Zeile:** Grid `Rang(serif, gedämpft) · Avatar 34 · Name+Gürtel · Anzahl
  (Serif 18)`, `--line-soft`-Unterlinien.

### Header & Bottom-Nav (global, `AppShell`)
- **Header** `.app-header`: 58px, `--surface`, Haarlinie unten, **dekoratives
  Wellen-Hintergrundmuster entfernen** (`background-image: none`). Links Logo +
  Wortmarke „VTKB Berlin" (Spectral 600, **Tinte statt Rot**) mit Mono-Unterzeile
  „ANWESENHEIT". Rechts Demo-Rollen-Select / Logout wie bisher.
- **Bottom-Nav** `.bottom-nav`: `--surface`, 4 Items, Labels in Plex 9.5px. Aktives
  Item: Rot **plus 2px roter Indikatorstrich oben** (`.nav-item.active::before`).

---

## Interactions & Behavior
Keine Verhaltensänderung gegenüber dem Ist-Stand. Nur visuelle States:
- **Hover** Primärbutton → `--red-strong`. Sekundär → `--surface-soft`.
- **Anwesend-Toggle:** Tap schaltet `.member-row` ↔ `.present` (Tint + roter
  Balken + roter Avatar + gefüllter Toggle).
- **Aktiver Nav-Reiter:** roter Indikatorstrich + rote Farbe.
- Transitions dezent (≤150ms, `background`/`border-color`).
- Touch-Targets ≥ 44px beibehalten (Buttons/Toggles 38–50px Höhe).

## State Management
Unverändert. Das Redesign berührt keine State-Logik, kein Routing, keine
Datenflüsse. Alle bestehenden Props/Screens (`AppScreen`, `DemoRole`,
`reviewEnabled` etc.) bleiben.

---

## ⚠ Gürtelsystem — Klärung nötig (Blocker für die Gürtel-Anzeige)
Die im Gespräch genannte Gürtelreihenfolge **weicht vom aktuellen Code ab**
(`packages/shared/src/belt.ts`, `BELT_CATALOG` / `BELT_COLORS`).

| Grad | Code-Stand (heute) | Vom Verein genannt |
|---|---|---|
| 9a. Kyu | `WEISS_ROT` (Weiß-Rot) | Weiß-Rot = **9. Kyu** |
| 9./9a | GELB = 9. Kyu | **9a = Weiß-Gelb** (`WEISS_GELB`, existiert im Code nicht) |
| 5a. Kyu | `BLAU_BRAUN` (Blau-Braun) | **nicht genannt** |
| 4. Kyu | `BRAUN` | **Violett** (`VIOLETT`, existiert im Code nicht) |

→ **Entscheidung erforderlich**, bevor die Gürtel-Anzeige final ist: Bleibt der
Code-Katalog maßgeblich, oder wird er auf die genannte Vereinsordnung umgestellt?
Bei Umstellung sind `BELT_COLORS`/`BELT_CATALOG` (und ggf. `beltLabels` in
`components.tsx`, Mockdaten, Tests) anzupassen — das ist eine **Daten-/Domänen-
Änderung**, kein reines Design. Die mitgelieferte `styles.redesign.css` enthält
**Farben für beide Systeme** (inkl. `belt-weiss_gelb`, `belt-violett`,
`belt-blau_braun`), sodass das CSS in jedem Fall passt.

Farbwerte: Weiß `#fff` · Gelb `#f2c200` · Orange `#e07b1e` · Grün `#2f8a4e` ·
Blau `#2f6fb0` · Violett `#6b4a9e` · Braun `#6e4327` · Schwarz `#1a1a1a`;
Halbgürtel als `linear-gradient(90deg, A 50%, B 50%)`.

---

## Assets
- **`VTKBLogo.png`** (liegt bei) — offizielles Vereinslogo (Oktagon, Tiger),
  transparenter Hintergrund. Ersetzt die bisherige `ToriiMark`-SVG im Header.
  - Nach `apps/web/public/VTKBLogo.png` kopieren.
  - In `components.tsx` `AppShell`: `<ToriiMark />` ersetzen durch
    `<img src="/VTKBLogo.png" alt="VTKB Berlin" width="30" height="30" style={{objectFit:"contain"}} />`
    (oder `import.meta`-Asset-Import). Die `ToriiMark`-Komponente kann entfallen,
    falls nirgends sonst genutzt.
  - Beachtet das Vite-`base` (GitHub Pages): Asset-Pfad ggf. über `import.meta.env.BASE_URL`
    auflösen, analog zur bestehenden PWA-Icon-Behandlung.
- Icons weiterhin `lucide-react` (`Home`, `Users`, `ClipboardCheck`, `BarChart3`).

---

## Implementation Plan (empfohlene Reihenfolge)
1. **Schriften** in `index.html` einbinden (Block oben).
2. **`styles.redesign.css`** in `src/styles.css` einarbeiten: zuerst den `:root`-
   Token-Block ersetzen (Abschnitt 1), dann die Klassen-Overrides (Abschnitte 2–13)
   übernehmen. Alternativ als separate Datei **nach** `styles.css` importieren.
3. **Logo-Swap** im `AppShell` (siehe Assets) + Wortmarke auf Tinte stellen.
4. **Header-Wellenmuster** entfernen (`background-image: none`).
5. **Nav-Indikator** `.nav-item.active::before` ergänzen.
6. Screens gegen `VTKB Redesign.dc.html` und die Screen-Beschreibungen abgleichen
   (Hero-Karte, Zähler, Mitgliedszeile, Prüfungs-Abschnitte, Stat-Streifen).
7. **Gürtelsystem klären** (Abschnitt oben) und ggf. Domänen-Anpassung separat.

## Files
- `VTKB Redesign.dc.html` — vollständige visuelle Referenz aller vier Screens +
  Gürtel-Legende. Im Browser öffenbar.
- `styles.redesign.css` — Token-Block + Klassen-Overrides, gemappt auf die
  bestehenden Klassennamen in `apps/web/src/styles.css`.
- `VTKBLogo.png` — Vereinslogo für den Header.

Relevante Bestands-Dateien im Repo:
- `apps/web/src/styles.css` — Ziel der Stil-Änderungen.
- `apps/web/src/components.tsx` — `AppShell`, `PageHeading`, Buttons, `MemberAvatar`,
  `BeltMark`, `StatusTag` (Logo-Swap hier).
- `apps/web/src/screens.tsx`, `reportingScreens.tsx` — die vier Screens.
- `packages/shared/src/belt.ts` — Gürtelkatalog (nur bei Systemumstellung).
